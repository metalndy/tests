# sifive-welcome
An example which demonstrates how to use timer, uart and mutex
